skeleton-viewer
===============

On the github, this repo can be found also here:

https://github.com/aimas-upb/skeleton-viewer

L Vladutu, dec. 2022
