package amilab.skeleton_viewer.client;

import com.google.gwt.core.client.GWT;

public class Services {

	public static DataServiceAsync dataService = GWT.create(DataService.class);
}
