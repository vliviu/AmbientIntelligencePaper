package amilab.skeleton_viewer.shared;

public interface MeasurmentsSet {

}
